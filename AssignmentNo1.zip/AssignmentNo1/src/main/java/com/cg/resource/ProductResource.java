package com.cg.resource;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.products.Products;
import com.cg.utility.ProductNotFoundException;
import com.cg.utility.ProductService;

@RestController
public class ProductResource {
	
	@Autowired
	private ProductService service;
	
	@GetMapping(path="/products")
    public void createProduct(@RequestBody Products prod) {
        System.out.println("inside createUser() of Controller" );
        Products savedProduct = service.save(prod);
    }
	
	@GetMapping(path = "/getproducts")
	public List<Products> retrieveAllProducts() {
		System.out.println("inside retrieveAllUsers() of Controller");
		return service.findAll();
	}
	
	@GetMapping(path = "/products/{id}")
	public Products retrieveProducts(@PathVariable int id) {
		System.out.println("inside retrieveUser() of Controller");
		Products prod = service.findOne(id);
		System.out.println("returned user " + prod);
		if (prod == null) {
			System.out.println("going to throw an Exception");
			throw new ProductNotFoundException("id-" + id);
		}
		return prod;
	}
	

}
