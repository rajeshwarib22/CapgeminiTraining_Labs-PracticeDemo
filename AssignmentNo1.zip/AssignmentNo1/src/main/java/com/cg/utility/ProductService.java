package com.cg.utility;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.ProductsInMemoryRepository;
import com.cg.products.Products;

@Service
public class ProductService {

	@Autowired
	private ProductsInMemoryRepository pdao;
	
	public List<Products> findAll() {
		System.out.println("inside findAll() of Service");
		return pdao.findAll();
	}
	
	public Products findOne(int id) {
				System.out.println("inside findOne(id) of Service");
        Optional<Products> user = pdao.findById(id);
        System.out.println("returning from findOne() of Service");
        return user.get();
	}

	public Products save(Products prod) {
		System.out.println("inside save() of Service");
		Products u = pdao.save(prod);
		return u;
	}
	
}
