package com.cg.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//run as spring boot application
// hit url:- http://localhost:8887/products on postman

@SpringBootApplication
public class RestServicesApplication {
	public static void main(String[] args) {
		SpringApplication.run(RestServicesApplication.class, args);
	}
}
