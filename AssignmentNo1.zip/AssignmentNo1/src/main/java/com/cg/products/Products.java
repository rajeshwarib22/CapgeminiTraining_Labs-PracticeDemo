package com.cg.products;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;


@Entity(name="products")
public class Products {
	@Id
	private int pid;
	@Column
	private String prodName;
	@Column
	private String prodPrice;

	public Products() {
		System.out.println("inside Product class");
	}

	public Products(int pid, String prodName, String prodPrice) {
		super();
		this.pid = pid;
		this.prodName = prodName;
		this.prodPrice = prodPrice;
	}

	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public String getProdName() {
		return prodName;
	}

	public void setProdName(String prodName) {
		this.prodName = prodName;
	}

	public String getProdPrice() {
		return prodPrice;
	}

	public void setProdPrice(String prodPrice) {
		this.prodPrice = prodPrice;
	}

	@Override
	public String toString() {
		return "Products [pid=" + pid + ", prodName=" + prodName + ", prodPrice=" + prodPrice + "]";
	}

}
