package com.cg.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.cg.products.Products;

@Repository
public class ProductsInMemoryRepository {
	private static List<Products> products = new ArrayList<Products>();

	static {
		products.add(new Products(1, "Redmi Y2", "12000"));
		products.add(new Products(2, "Bluetooth Headphones", "5000"));
		products.add(new Products(3, "Laptop", "40000"));
		products.add(new Products(4, "Ipad", "80000"));
	}

	public ProductsInMemoryRepository() {
		System.out.println("inside Products In Memory");
	}

	public Products save(Products prod) {
		System.out.println("inside save() of In-Memory Repository");
		products.add(prod);
		System.out.println(products);
		return prod;
	}

	public List<Products> findAll() {
		System.out.println("inside findAll() of In-Memory Repository");
		return products;
	}

	public Optional<Products> findById(int id) {
		System.out.println("inside findById() of In-Memory Repository");
		Products prod = products.stream().filter(a -> a.getPid() == id).findAny().orElse(null);
		Optional<Products> opt = Optional.ofNullable(prod);
		return opt;
	}

}
